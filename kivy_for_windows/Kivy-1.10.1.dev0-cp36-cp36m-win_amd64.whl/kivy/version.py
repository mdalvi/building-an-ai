# THIS FILE IS GENERATED FROM KIVY SETUP.PY
__version__ = '1.10.1.dev0'
__hash__ = '484b2f788a5c5cbf14f6d53b35d0d693eb01ec8a'
__date__ = '20170513'
